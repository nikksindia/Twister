//
//  Twister.h
//  Twister
//
//  Created by Nikhil Sharma on 02/07/18.
//  Copyright © 2018 Nikhil Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Twister.
FOUNDATION_EXPORT double TwisterVersionNumber;

//! Project version string for Twister.
FOUNDATION_EXPORT const unsigned char TwisterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Twister/PublicHeader.h>


